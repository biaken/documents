from setuptools import setup

VERSION='0.0.1'
setup(name='linalgnorm',
      version=VERSION,
      description='importlib failure expected',
      url='https://github.ibm.com/NGP-TWC/repository/',
      author='IBM',
      author_email='ibm@ibm.com',
      license='IBM',
      packages=[
            'linalg_norm'
      ],
      install_requires=['pandas', 'numpy', 'nltk', 'importlib', 'matplotlib', 'bs4', 'pickle'],
      zip_safe=False)
