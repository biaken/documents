from setuptools import setup

VERSION='0.0.2'
setup(name='linalgnorm',
      version=VERSION,
      description='dependencies successful expected',
      url='https://github.ibm.com/NGP-TWC/repository/',
      author='IBM',
      author_email='ibm@ibm.com',
      license='IBM',
      packages=[
            'linalg_norm'
      ],
      install_requires=['pandas', 'numpy', 'nltk', 'matplotlib', 'bs4'],
      zip_safe=False)
